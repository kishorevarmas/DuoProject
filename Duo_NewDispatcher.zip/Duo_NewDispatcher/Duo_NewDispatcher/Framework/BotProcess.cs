﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Data.SqlClient;
using Duo_NewDispatcher.Framework;


namespace Duo_NewDispatcher.Framework
{
    class BotProcess
    {

        public  DataRow ProcessTransaction(DataRow trnsactionItem)
        {
            SqlConnection con = new SqlConnection(Constants.CONSTRDB1);
            con.Open();
            SqlConnection conBB = new SqlConnection(Constants.CONSTRBB);
            conBB.Open();
            foreach (string file in Directory.GetFiles(Constants.INPUTPATH))
            {
                if (!File.Exists(file)) { continue; }
                string[] fileArr = file.Split("\\".ToCharArray());
                if (!fileArr[fileArr.Length - 1].Contains(".xlsx")) { continue; }
                if ((DateTime.Now - File.GetLastWriteTime(file)).TotalMinutes < 5) { continue; }
                string fTmp = fileArr[fileArr.Length - 1];
                if (!fTmp.StartsWith("DUO_")) { continue; }
                Excel.Application xlApp = null;
                Excel.Workbook xlWorkbook = null;
                Excel._Worksheet xlWorksheet = null;
                Excel.Range xlRange = null;
                try
                {
                    xlApp = new Excel.Application();
                    xlWorkbook = xlApp.Workbooks.Open(file);
                    xlWorksheet = xlWorkbook.Sheets[1];
                    xlRange = xlWorksheet.UsedRange;
                    int rowCount = xlRange.Rows.Count;
                    int colCount = xlRange.Columns.Count;

                    if (rowCount > 0)
                    {
                        if (xlApp.Cells[1, 1].Value.ToString().Equals("username") &&
                            xlApp.Cells[1, 2].Value.ToString().Equals("realname") &&
                            xlApp.Cells[1, 3].Value.ToString().Equals("alias1") &&
                            xlApp.Cells[1, 4].Value.ToString().Equals("alias2") &&
                            xlApp.Cells[1, 5].Value.ToString().Equals("email") &&
                            xlApp.Cells[1, 6].Value.ToString().Equals("status") &&
                            xlApp.Cells[1, 7].Value.ToString().Equals("phone1") &&
                            xlApp.Cells[1, 8].Value.ToString().Equals("phone2") &&
                            xlApp.Cells[1, 9].Value.ToString().Equals("platform1") &&
                            xlApp.Cells[1, 10].Value.ToString().Equals("platform2") &&
                            xlApp.Cells[1, 11].Value.ToString().Equals("EmployeeID") &&
                            xlApp.Cells[1, 12].Value.ToString().Equals("workdayphone") &&
                            xlApp.Cells[1, 13].Value.ToString().Equals("Requester_Email_Address") &&
                            xlApp.Cells[1, 14].Value.ToString().Equals("Supervisor_Email_Address") &&
                            xlApp.Cells[1, 15].Value.ToString().Equals("accountname") &&
                            xlApp.Cells[1, 16].Value.ToString().Equals("countryname"))
                        { }
                        for (int i = 2; i <= rowCount; i++)
                        {
                            string acntName = xlApp.Cells[i, 15].Value != null ? xlApp.Cells[i, 15].Value.ToString() : "";
                            SqlConnection conToUse = null;
                            if (acntName.ToLower().Equals("avalon"))
                            {
                                conToUse = conBB;
                            }
                            else
                            {
                                conToUse = con;
                            }

                            SqlCommand cmd = new SqlCommand("INSERT INTO [DUOProcessLogs]([file_name],[username],[realname],[alias1],[alias2],[email],[status],"
                                + "[phone1],[phone2],[platform1],[platform2],[EmployeeID],[workdayphone],[Requester_Email_Address],[Supervisor_Email_Address],[AccountName],"
                                + "[CountryName],[ETL_Created],[BOTStartTime],[BOTEndTime],[BOTStatus],[Comments],[EmailSent],[EmailTime],[Email_Count],[DUOAPIResponse],[Source])"
                                + " VALUES(@file_name, @username, @realname, @alias1, @alias2, @email, @status, @phone1, @phone2, @platform1, @platform2, @EmployeeID, @workdayphone,"
                                + " @Requester_Email_Address, @Supervisor_Email_Address, @AccountName, @CountryName, @ETL_Created, @BOTStartTime, @BOTEndTime, @BOTStatus,"
                                + " @Comments, @EmailSent, @EmailTime, @Email_Count, @DUOAPIResponse, @Source)", conToUse);
                            cmd.Parameters.AddWithValue("@file_name", fileArr[fileArr.Length - 1]);
                            cmd.Parameters.AddWithValue("@username", (xlApp.Cells[i, 1].Value != null ? xlApp.Cells[i, 1].Value.ToString() : ""));
                            cmd.Parameters.AddWithValue("@realname", (xlApp.Cells[i, 2].Value != null ? xlApp.Cells[i, 2].Value.ToString() : ""));
                            cmd.Parameters.AddWithValue("@alias1", xlApp.Cells[i, 3].Value != null ? xlApp.Cells[i, 3].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@alias2", xlApp.Cells[i, 4].Value != null ? xlApp.Cells[i, 4].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@email", xlApp.Cells[i, 5].Value != null ? xlApp.Cells[i, 5].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@status", xlApp.Cells[i, 6].Value != null ? xlApp.Cells[i, 6].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@phone1", xlApp.Cells[i, 7].Value != null ? xlApp.Cells[i, 7].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@phone2", xlApp.Cells[i, 8].Value != null ? xlApp.Cells[i, 8].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@platform1", xlApp.Cells[i, 9].Value != null ? xlApp.Cells[i, 9].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@platform2", xlApp.Cells[i, 10].Value != null ? xlApp.Cells[i, 10].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@EmployeeID", xlApp.Cells[i, 11].Value != null ? xlApp.Cells[i, 11].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@workdayphone", xlApp.Cells[i, 12].Value != null ? xlApp.Cells[i, 12].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@Requester_Email_Address", xlApp.Cells[i, 13].Value != null ? xlApp.Cells[i, 13].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@Supervisor_Email_Address", xlApp.Cells[i, 14].Value != null ? xlApp.Cells[i, 14].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@AccountName", xlApp.Cells[i, 15].Value != null ? xlApp.Cells[i, 15].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@CountryName", xlApp.Cells[i, 16].Value != null ? xlApp.Cells[i, 16].Value.ToString() : "");
                            cmd.Parameters.AddWithValue("@ETL_Created", File.GetCreationTime(file));
                            cmd.Parameters.AddWithValue("@BOTStartTime", DateTime.Now);
                            cmd.Parameters.AddWithValue("@BOTEndTime", DBNull.Value);
                            cmd.Parameters.AddWithValue("@BOTStatus", "New");
                            cmd.Parameters.AddWithValue("@Comments", "");
                            cmd.Parameters.AddWithValue("@EmailSent", "No");
                            cmd.Parameters.AddWithValue("@EmailTime", DBNull.Value);
                            cmd.Parameters.AddWithValue("@Email_Count", 0);
                            cmd.Parameters.AddWithValue("@DUOAPIResponse", "");
                            cmd.Parameters.AddWithValue("@Source", "Forms");
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception e) { }
                finally
                {
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    try { Marshal.ReleaseComObject(xlRange); } catch { }
                    try { Marshal.ReleaseComObject(xlWorksheet); } catch { }
                    try { xlWorkbook.Close(); } catch { }
                    try { Marshal.ReleaseComObject(xlWorkbook); } catch { }
                    try { xlApp.Quit(); } catch { }
                    try { Marshal.ReleaseComObject(xlApp); } catch { }
                    try
                    {
                        File.Move(file, Constants.PROCESSEDPATH + "Processed_" + fileArr[fileArr.Length - 1]);
                    }
                    catch (Exception e) { Console.WriteLine(e.Message); }
                }
            }
            try { con.Close(); } catch { }
            try { conBB.Close(); } catch { }
            return null;
        }
    }
}
