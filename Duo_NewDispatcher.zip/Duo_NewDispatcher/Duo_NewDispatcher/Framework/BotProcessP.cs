﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using Duo_NewDispatcher.Duo;
using System.Collections;
using System.Management.Automation;
using System.Collections.ObjectModel;

namespace Duo_NewDispatcher.Framework
{
    class BotProcessP
    {
        public  DataRow ProcessTransaction(DataRow trnsactionItem)
        {
            DataTable dtNewRecord = new DataTable();
            string duoResponse = null;
            SqlConnection con = new SqlConnection(Constants.CONSTRDB1.ToString());
            SqlConnection conBB = new SqlConnection(Constants.CONSTRBB.ToString());
            conBB.Open();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT TOP (45) * FROM [DUOProcessLogs] WHERE BOTStatus='New'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dtNewRecord);
                da.Dispose();

                DataTable dtBB = new DataTable();
                cmd = new SqlCommand("SELECT TOP (45) * FROM [DUOProcessLogs] WHERE BOTStatus='New'", conBB);
                da = new SqlDataAdapter(cmd);
                da.Fill(dtBB);
                da.Dispose();

                dtNewRecord.Merge(dtBB);

                foreach (DataRow row in dtNewRecord.Rows)
                {
                    duoResponse = null;
                    SqlConnection conToUse = null;
                    DateTime startTime = DateTime.Now;
                    duoResponse = performDuoEnrollment((row["username"] != null ? row["username"].ToString() : ""),
                        (row["alias1"] != null ? row["alias1"].ToString() : ""),
                        (row["realname"] != null ? row["realname"].ToString() : ""),
                        (row["email"] != null ? row["email"].ToString() : ""),
                        (row["alias2"] != null ? row["alias2"].ToString() : ""),
                        (row["platform1"] != null ? row["platform1"].ToString() : ""),
                        (row["phone1"] != null ? row["phone1"].ToString() : ""));

                    string acntName = row["AccountName"].ToString().ToLower();
                    if (acntName.Equals("avalon"))
                    {
                        conToUse = conBB;
                    }
                    else
                    {
                        conToUse = con;
                    }

                    if (!duoResponse.ToLower().Contains("fail"))
                    {
                        string psScript = null;
                        if (acntName.Equals("avalon"))
                        {
                            psScript = "$outObject=@{}" + System.Environment.NewLine
                            + "$outObject += @{\"error\"=\"false\"}" + System.Environment.NewLine
                            + "$outObject += @{\"msg\"=\"\"}" + System.Environment.NewLine
                            + "try{" + System.Environment.NewLine
                            + "$useremail=\"replace_email\"" + System.Environment.NewLine
                            + "$server =  \"10.5.11.16\"" + System.Environment.NewLine
                            + "$username1 = \"botcnx.pwdreset\"" + System.Environment.NewLine
                            + "$password1 = \"replace_password\" | ConvertTo-SecureString -asPlainText -Force" + System.Environment.NewLine
                            + "$credential = New-Object System.Management.Automation.PSCredential($username1,$password1)" + System.Environment.NewLine
                            + "$user = Get-ADuser -LDAPFilter \"(UserPrincipalName=$useremail)\" -Credential $credential -server $server -ErrorAction Stop" + System.Environment.NewLine
                            + "set-aduser -Identity $user -Credential $credential -server $server -replace @{cnxDuoEn=$true} -ErrorAction Stop" + System.Environment.NewLine
                            + "$outObject[\"error\"] = \"false\"" + System.Environment.NewLine
                            + "}Catch{" + System.Environment.NewLine
                            + "$outObject[\"msg\"] =$_.Exception.Message" + System.Environment.NewLine
                            + "$outObject[\"error\"] = \"true\"" + System.Environment.NewLine
                            + "}" + System.Environment.NewLine
                            + "$outObject";
                        }
                        else
                        {
                            psScript = "$outObject=@{}" + System.Environment.NewLine
                            + "$outObject += @{\"error\"=\"false\"}" + System.Environment.NewLine
                            + "$outObject += @{\"msg\"=\"\"}" + System.Environment.NewLine
                            + "try{" + System.Environment.NewLine
                            + "$useremail=\"replace_email\"" + System.Environment.NewLine
                            + "$server =  \"10.5.11.16\"" + System.Environment.NewLine
                            + "$username1 = \"botcnx.pwdreset\"" + System.Environment.NewLine
                            + "$password1 = \"replace_password\" | ConvertTo-SecureString -asPlainText -Force" + System.Environment.NewLine
                            + "$credential = New-Object System.Management.Automation.PSCredential($username1,$password1)" + System.Environment.NewLine
                            + "$user = Get-ADuser -LDAPFilter \"(UserPrincipalName=$useremail)\" -Credential $credential -server $server -ErrorAction Stop" + System.Environment.NewLine
                            + "set-aduser -Identity $user -Credential $credential -server $server -replace @{cnxDuoEn=$true} -ErrorAction Stop" + System.Environment.NewLine
                            + "Add-ADGroupMember -Identity \"sec_grp_duo_phonecall_block\" -Members $user  -Credential $credential -server $server -ErrorAction Stop" + System.Environment.NewLine
                            + "$outObject[\"error\"] = \"false\"" + System.Environment.NewLine
                            + "}Catch{" + System.Environment.NewLine
                            + "$outObject[\"msg\"] =$_.Exception.Message" + System.Environment.NewLine
                            + "$outObject[\"error\"] = \"true\"" + System.Environment.NewLine
                            + "}" + System.Environment.NewLine
                            + "$outObject";
                        }
                        psScript = psScript.Replace("replace_email", row["email"].ToString().ToLower().Trim());
                        psScript = psScript.Replace("replace_password", "botcnx.pwdreset".ToString());

                        try
                        {
                            PowerShell psInstance = PowerShell.Create();
                            psInstance.AddScript(psScript);
                            Collection<PSObject> psOutput = psInstance.Invoke();
                            foreach (PSObject outputItem in psOutput)
                            {
                                if (outputItem != null)
                                {
                                    try
                                    {
                                        Console.WriteLine((((Hashtable)outputItem.BaseObject)["msg"]).ToString());
                                        Console.WriteLine((((Hashtable)outputItem.BaseObject)["error"]).ToString());
                                    }
                                    catch { }
                                }
                            }
                        }
                        catch { }
                    }
                    cmd = new SqlCommand("UPDATE [DUOProcessLogs] SET [BOTEndTime] = @BOTEndTime,"
                            + " [BOTStatus] = @BOTStatus, [Comments] = @Comments, [DUOAPIResponse] = @DUOAPIResponse WHERE Id=@Id", conToUse);
                    cmd.Parameters.AddWithValue("@BOTEndTime", DateTime.Now);
                    cmd.Parameters.AddWithValue("@BOTStatus", (duoResponse.ToLower().Contains("fail") ? "Exception" : "Success"));
                    cmd.Parameters.AddWithValue("@Comments", duoResponse);
                    cmd.Parameters.AddWithValue("@DUOAPIResponse", duoResponse);
                    cmd.Parameters.AddWithValue("@Id", row["Id"]);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e) { }
            finally
            {
                try { con.Close(); } catch { }
                try { conBB.Close(); } catch { }
            }
            return null;
        }
        private string performDuoEnrollment(string inputUser, string inputAlias1, string realName,
            string inputEmail, string inputAlies2, string platform, string inputNO)
        {
            string output = "Fail";
            try
            {
                DuoApi client = new DuoApi(Constants.DUO_IKEY, Constants.DUO_SKEY, Constants.DUOENDPOINT);

                // Get user by username.
                var parameters = new Dictionary<string, string>();
                parameters.Add("username", inputUser);
                var users = client.JSONApiCall<System.Collections.ArrayList>(
                    "GET", "/admin/v1/users", parameters, 60000);

                // if user not found create user
                if (users.Count == 0)
                {
                    // creating user
                    CreateUser(client, inputUser, inputAlias1, realName, inputEmail, inputAlies2);

                    //allowing system to reflact record wait
                    System.Threading.Thread.Sleep(1000);

                    // Get created user.
                    parameters = new Dictionary<string, string>();
                    parameters.Add("username", inputUser);
                    users = client.JSONApiCall<System.Collections.ArrayList>(
                        "GET", "/admin/v1/users", parameters, 60000);
                }

                if (users.Count > 0)
                {
                    foreach (Dictionary<string, object> user in users)
                    {
                        string userId = user["user_id"].ToString();
                        ArrayList phones = (ArrayList)user["phones"];
                        if (phones.Count > 0)
                        {
                            // Fetch from all phone array
                            Dictionary<string, object> phone0 = (Dictionary<string, object>)phones[0];

                            // is phone activated
                            bool isActive = Boolean.Parse(phone0["activated"].ToString());
                            string phoneNo = phone0["number"].ToString();
                            string pType = phone0["type"].ToString().ToLower();
                            string pPlatform = phone0["platform"].ToString().ToLower();
                            bool smsStatus = false;
                            string phoneId = phone0["phone_id"].ToString();
                            if (!isActive)
                            {
                                if (pType.Contains("landline"))
                                {
                                    output = "Success - User:" + inputUser + " | Phone is Landline.";
                                    smsStatus = true;
                                }
                                else if (pType.Contains("unknown") || pPlatform.Contains("unknown"))
                                {
                                    ModifyPhone(client, phoneId, platform);
                                    smsStatus = sendSMS(client, phoneId, inputNO, inputUser);
                                    output = "Success - User:" + inputUser + " | SMS Sent.";
                                }
                                else if (!pType.Contains("landline") && !smsStatus)
                                {
                                    smsStatus = sendSMS(client, phoneId, inputNO, inputUser);
                                    output = "Success - User:" + inputUser + " | SMS Sent.";
                                }
                                if (!smsStatus)
                                {
                                    output = "Fail - " + "Phone: " + phoneNo + " | Type: " + pType + " | Platform: " + pPlatform;
                                }
                            }
                            else
                            {
                                output = "Success - " + inputUser + " | User phone is active.";
                                break;
                            }
                        }
                        else //if no phone created for user
                        {
                            string phoneId = GetPhoneId(client, inputNO);
                            if (phoneId == null)
                            {
                                //creating new phone for user
                                parameters = new Dictionary<string, string>();
                                parameters.Add("number", inputNO);
                                if (platform.ToLower().Contains("landline"))
                                {
                                    parameters.Add("type", platform);
                                }
                                else
                                {
                                    parameters.Add("platform", platform);
                                    parameters.Add("type", "Mobile");
                                }
                                var newPhone = client.JSONApiCall<System.Collections.ArrayList>(
                                            "POST", "/admin/v1/phones", parameters, 60000);
                            }
                            System.Threading.Thread.Sleep(1000);

                            // Retrive created id
                            phoneId = GetPhoneId(client, inputNO);

                            //Associate Phone with User
                            if (phoneId != null)
                            {
                                output = "Success";
                                parameters = new Dictionary<string, string>();
                                parameters.Add("phone_id", phoneId);
                                var newAssociate = client.JSONApiCall<System.Collections.ArrayList>(
                                            "POST", "/admin/v1/users/" + userId + "/phones", parameters, 60000);

                                if (platform.ToLower().Contains("landline"))
                                {
                                    output = "Success - User:" + inputUser + " | Phone is Landline.";
                                }
                                else
                                {
                                    bool smsStatus = sendSMS(client, phoneId, inputNO, inputUser);
                                    output = "Success - User:" + inputUser + " | SMS Sent.";
                                    if (!smsStatus)
                                    {
                                        output = "Fail - " + "Phone: " + inputNO + " | Id: " + phoneId + " | Platform: " + platform;
                                    }

                                }
                            }
                            else
                            {
                                output = "Fail - User:" + inputUser + " | Cannot create phone id.";
                            }
                        }
                    }
                }
                else
                {
                    output = "Fail - User:" + inputUser + " | Couldnot create user.";
                }
            }
            catch (Exception e)
            {
                output = "Fail - " + e.Message;
            }
            return output;
        }


        private void ModifyPhone(DuoApi client, string phoneId, string platform)
        {
            //modify phone to Mobile
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("platform", platform);
            parameters.Add("type", "Mobile");
            var modifyResponse = client.JSONApiCall<System.Collections.ArrayList>(
                "POST", "/admin/v1/phones/" + phoneId + "", parameters, 60000);
        }

        private bool sendSMS(DuoApi client, string phoneId, string phoneNo, string userName)
        {
            try
            {
                Dictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("valid_secs", "86400");
                var phoneSMS = client.JSONApiCall<System.Collections.ArrayList>(
                    "POST", "/admin/v1/phones/" + phoneId + "/send_sms_activation", parameters, 60000);
                Console.WriteLine("DUO API - SMS Sent to user: " + userName + "  PhoneNo:  " + phoneNo);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        private void CreateUser(DuoApi client, string inputUser, string inputAlias1, string RealName, string inputEmail, string inputAlias2)
        {
            //creatign new user
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("username", inputUser);
            parameters.Add("alias1", inputAlias1);
            parameters.Add("alias2", inputAlias2);
            parameters.Add("realname", RealName);
            parameters.Add("email", inputEmail);
            parameters.Add("staus", "active");
            var newUser = client.JSONApiCall<System.Collections.ArrayList>(
                        "POST", "/admin/v1/users", parameters, 60000);
        }

        private string GetPhoneId(DuoApi client, string inputNO)
        {
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("number", inputNO);
            var oldPhone = client.JSONApiCall<System.Collections.ArrayList>(
                        "GET", "/admin/v1/phones", parameters, 60000);
            try
            {
                Dictionary<string, object> phoneOldDic = (Dictionary<string, object>)oldPhone[0];
                string phoneid = phoneOldDic["phone_id"].ToString();
                if (String.IsNullOrEmpty(phoneid))
                {
                    return null;
                }
                return phoneid;
            }
            catch (Exception ep)
            {
                return null;
            }
        }
    }
}
