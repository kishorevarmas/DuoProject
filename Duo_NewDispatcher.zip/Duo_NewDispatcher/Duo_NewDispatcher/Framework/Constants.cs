﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duo_NewDispatcher.Framework
{
    class Constants
    {
        public static string CONSTRDB1 = "Server=LAPTOP-7BM2GUO9;Database=DB_Office;Trusted_Connection=True;";

        public static string CONSTRBB = "Server = LAPTOP-7BM2GUO9;Database=DB_Office;Trusted_Connection=True;";
        public static string INPUTPATH = @"C:\Duo Files\Input\";
        public static string PROCESSEDPATH = @"C:\Duo Files\Processed\";
        public static string DUOENDPOINT = "api-c1111111.duosecurity.com";
        public static string DUO_IKEY = "TESTDUOIKEY";
        public static string DUO_SKEY = "testsecretkey";
        public static string pwdreset = "botcnx.pwdreset";

    }
}
