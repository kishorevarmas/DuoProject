﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duo_NewDispatcher.Framework;

namespace Duo_NewDispatcher
{
    class Program
    {
        static void Main(string[] args)
        {
            //BotProcess process = new BotProcess();
            BotProcessP process2 = new BotProcessP();
            //process.ProcessTransaction(null);
            process2.ProcessTransaction(null);
        }
    }
}
